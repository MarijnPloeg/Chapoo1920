﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ChapooModel;

namespace ChapooDAL
{
    public class Menu_Item_DAO : Base
    {
        public List<Menu_Item> DB_Get_MenuItems()
        {
            string query = "SELECT [Naam], [voorraad] FROM [Menu_Items]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Menu_Item> ReadTables(DataTable dataTable)
        {
            List<Menu_Item> menuItems = new List<Menu_Item>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Menu_Item menuItem = new Menu_Item()
                {
                    Naam = (string)dr["Naam"].ToString(),
                    Voorraad = (int)dr["Voorraad"]
                };
                menuItems.Add(menuItem);
            }
            return menuItems;
        }
    }
}
