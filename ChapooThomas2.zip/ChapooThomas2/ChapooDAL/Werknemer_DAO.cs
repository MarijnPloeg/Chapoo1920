﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using ChapooModel;

namespace ChapooDAL
{
    public class Werknemer_DAO : Base
    {
        public List<Werknemer> DB_Get_Werknemers()
        {
            string query = "SELECT [Name], [Type] FROM [Employee]";
            SqlParameter[] sqlParameters = new SqlParameter[0];
            return ReadTables(ExecuteSelectQuery(query, sqlParameters));
        }

        private List<Werknemer> ReadTables(DataTable dataTable)
        {
            List<Werknemer> werknemers = new List<Werknemer>();

            foreach (DataRow dr in dataTable.Rows)
            {
                Werknemer werknemer = new Werknemer()
                {
                    Naam = (string)dr["Name"].ToString(),
                    Functie = (Functie)dr["Type"]
                };
                werknemers.Add(werknemer);
            }
            return werknemers;
        }
    }
}
