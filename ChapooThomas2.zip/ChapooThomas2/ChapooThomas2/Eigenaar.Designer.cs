﻿namespace ChapooThomas2
{
    partial class Eigenaar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl_Voorraad = new System.Windows.Forms.Panel();
            this.lbl_Voorraad = new System.Windows.Forms.Label();
            this.lv_Voorraad = new System.Windows.Forms.ListView();
            this.col_Voorraad_Naam = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.col_Voorraad_Voorraad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btn_Voorraad_Terug = new System.Windows.Forms.Button();
            this.pnl_Werknemers = new System.Windows.Forms.Panel();
            this.lbl_Werknemers = new System.Windows.Forms.Label();
            this.btn_Werknemers_Terug = new System.Windows.Forms.Button();
            this.pnl_Hoofdmenu = new System.Windows.Forms.Panel();
            this.btn_Werknemers = new System.Windows.Forms.Button();
            this.btn_Recensies = new System.Windows.Forms.Button();
            this.btn_Financiën = new System.Windows.Forms.Button();
            this.btn_Voorraad = new System.Windows.Forms.Button();
            this.pnl_Voorraad.SuspendLayout();
            this.pnl_Werknemers.SuspendLayout();
            this.pnl_Hoofdmenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Voorraad
            // 
            this.pnl_Voorraad.Controls.Add(this.lbl_Voorraad);
            this.pnl_Voorraad.Controls.Add(this.lv_Voorraad);
            this.pnl_Voorraad.Controls.Add(this.btn_Voorraad_Terug);
            this.pnl_Voorraad.Location = new System.Drawing.Point(12, 12);
            this.pnl_Voorraad.Name = "pnl_Voorraad";
            this.pnl_Voorraad.Size = new System.Drawing.Size(1240, 657);
            this.pnl_Voorraad.TabIndex = 0;
            // 
            // lbl_Voorraad
            // 
            this.lbl_Voorraad.AutoSize = true;
            this.lbl_Voorraad.Location = new System.Drawing.Point(81, 69);
            this.lbl_Voorraad.Name = "lbl_Voorraad";
            this.lbl_Voorraad.Size = new System.Drawing.Size(50, 13);
            this.lbl_Voorraad.TabIndex = 4;
            this.lbl_Voorraad.Text = "Voorraad";
            // 
            // lv_Voorraad
            // 
            this.lv_Voorraad.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.col_Voorraad_Naam,
            this.col_Voorraad_Voorraad});
            this.lv_Voorraad.HideSelection = false;
            this.lv_Voorraad.Location = new System.Drawing.Point(84, 85);
            this.lv_Voorraad.Name = "lv_Voorraad";
            this.lv_Voorraad.Size = new System.Drawing.Size(570, 497);
            this.lv_Voorraad.TabIndex = 3;
            this.lv_Voorraad.UseCompatibleStateImageBehavior = false;
            this.lv_Voorraad.View = System.Windows.Forms.View.Details;
            // 
            // col_Voorraad_Naam
            // 
            this.col_Voorraad_Naam.Text = "Naam";
            this.col_Voorraad_Naam.Width = 150;
            // 
            // col_Voorraad_Voorraad
            // 
            this.col_Voorraad_Voorraad.Text = "Voorraad";
            this.col_Voorraad_Voorraad.Width = 150;
            // 
            // btn_Voorraad_Terug
            // 
            this.btn_Voorraad_Terug.Location = new System.Drawing.Point(3, 3);
            this.btn_Voorraad_Terug.Name = "btn_Voorraad_Terug";
            this.btn_Voorraad_Terug.Size = new System.Drawing.Size(75, 23);
            this.btn_Voorraad_Terug.TabIndex = 0;
            this.btn_Voorraad_Terug.Text = "Terug";
            this.btn_Voorraad_Terug.UseVisualStyleBackColor = true;
            // 
            // pnl_Werknemers
            // 
            this.pnl_Werknemers.Controls.Add(this.lbl_Werknemers);
            this.pnl_Werknemers.Controls.Add(this.btn_Werknemers_Terug);
            this.pnl_Werknemers.Location = new System.Drawing.Point(12, 12);
            this.pnl_Werknemers.Name = "pnl_Werknemers";
            this.pnl_Werknemers.Size = new System.Drawing.Size(1240, 657);
            this.pnl_Werknemers.TabIndex = 1;
            // 
            // lbl_Werknemers
            // 
            this.lbl_Werknemers.AutoSize = true;
            this.lbl_Werknemers.Location = new System.Drawing.Point(137, 13);
            this.lbl_Werknemers.Name = "lbl_Werknemers";
            this.lbl_Werknemers.Size = new System.Drawing.Size(67, 13);
            this.lbl_Werknemers.TabIndex = 3;
            this.lbl_Werknemers.Text = "Werknemers";
            // 
            // btn_Werknemers_Terug
            // 
            this.btn_Werknemers_Terug.Location = new System.Drawing.Point(3, 3);
            this.btn_Werknemers_Terug.Name = "btn_Werknemers_Terug";
            this.btn_Werknemers_Terug.Size = new System.Drawing.Size(75, 23);
            this.btn_Werknemers_Terug.TabIndex = 2;
            this.btn_Werknemers_Terug.Text = "Terug";
            this.btn_Werknemers_Terug.UseVisualStyleBackColor = true;
            // 
            // pnl_Hoofdmenu
            // 
            this.pnl_Hoofdmenu.Controls.Add(this.btn_Werknemers);
            this.pnl_Hoofdmenu.Controls.Add(this.btn_Recensies);
            this.pnl_Hoofdmenu.Controls.Add(this.btn_Financiën);
            this.pnl_Hoofdmenu.Controls.Add(this.btn_Voorraad);
            this.pnl_Hoofdmenu.Location = new System.Drawing.Point(12, 12);
            this.pnl_Hoofdmenu.Name = "pnl_Hoofdmenu";
            this.pnl_Hoofdmenu.Size = new System.Drawing.Size(1241, 657);
            this.pnl_Hoofdmenu.TabIndex = 2;
            // 
            // btn_Werknemers
            // 
            this.btn_Werknemers.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Werknemers.Location = new System.Drawing.Point(394, 352);
            this.btn_Werknemers.Name = "btn_Werknemers";
            this.btn_Werknemers.Size = new System.Drawing.Size(200, 100);
            this.btn_Werknemers.TabIndex = 16;
            this.btn_Werknemers.Text = "Werknemers";
            this.btn_Werknemers.UseVisualStyleBackColor = true;
            // 
            // btn_Recensies
            // 
            this.btn_Recensies.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Recensies.Location = new System.Drawing.Point(647, 205);
            this.btn_Recensies.Name = "btn_Recensies";
            this.btn_Recensies.Size = new System.Drawing.Size(200, 100);
            this.btn_Recensies.TabIndex = 15;
            this.btn_Recensies.Text = "Recensies";
            this.btn_Recensies.UseVisualStyleBackColor = true;
            // 
            // btn_Financiën
            // 
            this.btn_Financiën.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Financiën.Location = new System.Drawing.Point(647, 352);
            this.btn_Financiën.Name = "btn_Financiën";
            this.btn_Financiën.Size = new System.Drawing.Size(200, 100);
            this.btn_Financiën.TabIndex = 14;
            this.btn_Financiën.Text = "Financiën";
            this.btn_Financiën.UseVisualStyleBackColor = true;
            // 
            // btn_Voorraad
            // 
            this.btn_Voorraad.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Voorraad.Location = new System.Drawing.Point(394, 205);
            this.btn_Voorraad.Name = "btn_Voorraad";
            this.btn_Voorraad.Size = new System.Drawing.Size(200, 100);
            this.btn_Voorraad.TabIndex = 13;
            this.btn_Voorraad.Text = "Voorraad";
            this.btn_Voorraad.UseVisualStyleBackColor = true;
            // 
            // Eigenaar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.pnl_Werknemers);
            this.Controls.Add(this.pnl_Voorraad);
            this.Controls.Add(this.pnl_Hoofdmenu);
            this.Name = "Eigenaar";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Eigenaar_Load);
            this.pnl_Voorraad.ResumeLayout(false);
            this.pnl_Voorraad.PerformLayout();
            this.pnl_Werknemers.ResumeLayout(false);
            this.pnl_Werknemers.PerformLayout();
            this.pnl_Hoofdmenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Voorraad;
        private System.Windows.Forms.Label lbl_Voorraad;
        private System.Windows.Forms.ListView lv_Voorraad;
        private System.Windows.Forms.ColumnHeader col_Voorraad_Naam;
        private System.Windows.Forms.ColumnHeader col_Voorraad_Voorraad;
        private System.Windows.Forms.Button btn_Voorraad_Terug;
        private System.Windows.Forms.Panel pnl_Werknemers;
        private System.Windows.Forms.Label lbl_Werknemers;
        private System.Windows.Forms.Button btn_Werknemers_Terug;
        private System.Windows.Forms.Panel pnl_Hoofdmenu;
        private System.Windows.Forms.Button btn_Werknemers;
        private System.Windows.Forms.Button btn_Recensies;
        private System.Windows.Forms.Button btn_Financiën;
        private System.Windows.Forms.Button btn_Voorraad;
    }
}

