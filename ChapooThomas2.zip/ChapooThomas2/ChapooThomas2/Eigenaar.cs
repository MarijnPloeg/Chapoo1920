﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ChapooLogic;
using ChapooModel;

namespace ChapooThomas2
{
    public partial class Eigenaar : Form
    {
        public Eigenaar()
        {
            InitializeComponent();
        }

        private void Eigenaar_Load(object sender, EventArgs e)
        {
            showPanel("Hoofdmenu");
        }

        private void showPanel(string panelName)
        {
            if (panelName == "Hoofdmenu")
            {
                pnl_Hoofdmenu.Show();

                pnl_Voorraad.Hide();
                pnl_Werknemers.Hide();
            }
            else if (panelName == "Voorraad")
            {
                pnl_Voorraad.Show();

                pnl_Hoofdmenu.Hide();
                pnl_Werknemers.Hide();

                ChapooLogic.MenuItem_Service menuItem_Service = new ChapooLogic.MenuItem_Service();
                List<MenuItem> menuItems = menuItem_Service.GetMenuItems();

                lv_Voorraad.Items.Clear();

                foreach (ChapooModel.MenuItem mI in menuItems)
                {
                    ListViewItem li = new ListViewItem(mI.Naam);
                    li.SubItems.Add(mI.Voorraad.ToString());
                    lv_Voorraad.Items.Add(li);
                }

            }
            else if (panelName == "Werknemers")
            {
                pnl_Werknemers.Show();

                pnl_Voorraad.Hide();
                pnl_Hoofdmenu.Hide();
            }
        }

        private void btn_Voorraad_Click(object sender, EventArgs e)
        {
            showPanel("Voorraad");
        }

        private void btn_Werknemers_Click(object sender, EventArgs e)
        {
            showPanel("Werknemers");
        }

        private void btn_Menu_Click(object sender, EventArgs e)
        {
            showPanel("Menu");
        }

        private void btn_Voorraad_Terug_Click(object sender, EventArgs e)
        {
            showPanel("Hoofdmenu");
        }

        private void btn_Menu_Terug_Click(object sender, EventArgs e)
        {
            showPanel("Hoofdmenu");
        }

        private void btn_Werknemers_Terug_Click(object sender, EventArgs e)
        {
            showPanel("Hoofdmenu");
        }
    }
}
