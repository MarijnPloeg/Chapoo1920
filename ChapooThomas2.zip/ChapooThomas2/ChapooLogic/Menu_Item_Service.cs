﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ChapooDAL;
using ChapooModel;


namespace ChapooLogic
{
    public class Menu_Item_Service
    {
        Menu_Item_DAO menuItem_db = new Menu_Item_DAO();

        public List<Menu_Item> GetMenuItems()
        {
            List<Menu_Item> menuItems = menuItem_db.DB_Get_MenuItems();
            return menuItems;
        }
    }
}
