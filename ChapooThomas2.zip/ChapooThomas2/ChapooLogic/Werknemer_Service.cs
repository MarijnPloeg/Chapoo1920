﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ChapooDAL;
using ChapooModel;

namespace ChapooLogic
{
    public class Werknemer_Service
    {
        Werknemer_DAO werknemer_db = new Werknemer_DAO();

        public List<Werknemer> GetWerknemers()
        {
            List<Werknemer> werknemers = werknemer_db.DB_Get_Werknemers();
            return werknemers;
        }
    }
}
