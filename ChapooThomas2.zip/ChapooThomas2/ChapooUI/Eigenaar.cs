﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ChapooModel;
using ChapooLogic;
using ChapooDAL;

namespace ChapooUI
{
    public partial class Eigenaar : Form
    {
        public Eigenaar()
        {
            InitializeComponent();
        }

        private void showPanel(string panelName)
        {
            if (panelName == "Hoofdmenu")
            {
                pnl_Hoofdmenu.Show();

                pnl_Voorraad.Hide();
                pnl_Werknemers.Hide();
            }
            else if (panelName == "Voorraad")
            {
                pnl_Voorraad.Show();

                pnl_Hoofdmenu.Hide();
                pnl_Werknemers.Hide();

                ChapooLogic.Menu_Item_Service menuItem_Service = new ChapooLogic.Menu_Item_Service();
                List<Menu_Item> menuItems = menuItem_Service.GetMenuItems();

                lv_Voorraad.Items.Clear();

                foreach(ChapooModel.Menu_Item mI in menuItems)
                {
                    ListViewItem li = new ListViewItem(mI.Naam);
                    li.SubItems.Add(mI.Voorraad.ToString());
                    lv_Voorraad.Items.Add(li);
                }
            }
            else if(panelName == "Werknemers")
            {
                pnl_Werknemers.Show();

                pnl_Hoofdmenu.Hide();
                pnl_Voorraad.Hide();

                ChapooLogic.Werknemer_Service werknemer_Service = new ChapooLogic.Werknemer_Service();
                List<Werknemer> werknemers = werknemer_Service.GetWerknemers();

                foreach(ChapooModel.Werknemer w in werknemers)
                {
                    ListViewItem li = new ListViewItem(w.Naam);
                    li.SubItems.Add(w.Functie.ToString());
                    lv_Werknemers.Items.Add(li);
                }
            }
        }

        private void Eigenaar_Load(object sender, EventArgs e)
        {
            showPanel("Hoofdmenu");
        }

        private void btn_Eigenaar_Voorraad_Click(object sender, EventArgs e)
        {
            showPanel("Voorraad");
        }

        private void btn_Eigenaar_Werknemers_Click(object sender, EventArgs e)
        {
            showPanel("Werknemers");
        }
    }
}
