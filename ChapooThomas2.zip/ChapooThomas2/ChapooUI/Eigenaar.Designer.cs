﻿namespace ChapooUI
{
    partial class Eigenaar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("");
            System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("");
            this.pnl_Hoofdmenu = new System.Windows.Forms.Panel();
            this.btn_Eigenaar_Werknemers = new System.Windows.Forms.Button();
            this.btn_Eigenaar_Voorraad = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl_Voorraad = new System.Windows.Forms.Panel();
            this.lv_Voorraad = new System.Windows.Forms.ListView();
            this.label2 = new System.Windows.Forms.Label();
            this.pnl_Werknemers = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lv_Werknemers = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pnl_Hoofdmenu.SuspendLayout();
            this.pnl_Voorraad.SuspendLayout();
            this.pnl_Werknemers.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl_Hoofdmenu
            // 
            this.pnl_Hoofdmenu.Controls.Add(this.btn_Eigenaar_Werknemers);
            this.pnl_Hoofdmenu.Controls.Add(this.btn_Eigenaar_Voorraad);
            this.pnl_Hoofdmenu.Controls.Add(this.label1);
            this.pnl_Hoofdmenu.Location = new System.Drawing.Point(12, 12);
            this.pnl_Hoofdmenu.Name = "pnl_Hoofdmenu";
            this.pnl_Hoofdmenu.Size = new System.Drawing.Size(776, 426);
            this.pnl_Hoofdmenu.TabIndex = 0;
            // 
            // btn_Eigenaar_Werknemers
            // 
            this.btn_Eigenaar_Werknemers.Location = new System.Drawing.Point(211, 188);
            this.btn_Eigenaar_Werknemers.Name = "btn_Eigenaar_Werknemers";
            this.btn_Eigenaar_Werknemers.Size = new System.Drawing.Size(75, 23);
            this.btn_Eigenaar_Werknemers.TabIndex = 2;
            this.btn_Eigenaar_Werknemers.Text = "Werknemers";
            this.btn_Eigenaar_Werknemers.UseVisualStyleBackColor = true;
            this.btn_Eigenaar_Werknemers.Click += new System.EventHandler(this.btn_Eigenaar_Werknemers_Click);
            // 
            // btn_Eigenaar_Voorraad
            // 
            this.btn_Eigenaar_Voorraad.Location = new System.Drawing.Point(211, 159);
            this.btn_Eigenaar_Voorraad.Name = "btn_Eigenaar_Voorraad";
            this.btn_Eigenaar_Voorraad.Size = new System.Drawing.Size(75, 23);
            this.btn_Eigenaar_Voorraad.TabIndex = 1;
            this.btn_Eigenaar_Voorraad.Text = "Voorraad";
            this.btn_Eigenaar_Voorraad.UseVisualStyleBackColor = true;
            this.btn_Eigenaar_Voorraad.Click += new System.EventHandler(this.btn_Eigenaar_Voorraad_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Hoofdmenu";
            // 
            // pnl_Voorraad
            // 
            this.pnl_Voorraad.Controls.Add(this.lv_Voorraad);
            this.pnl_Voorraad.Controls.Add(this.label2);
            this.pnl_Voorraad.Location = new System.Drawing.Point(12, 12);
            this.pnl_Voorraad.Name = "pnl_Voorraad";
            this.pnl_Voorraad.Size = new System.Drawing.Size(776, 426);
            this.pnl_Voorraad.TabIndex = 1;
            // 
            // lv_Voorraad
            // 
            this.lv_Voorraad.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader3,
            this.columnHeader4});
            this.lv_Voorraad.HideSelection = false;
            this.lv_Voorraad.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
            listViewItem1,
            listViewItem2});
            this.lv_Voorraad.Location = new System.Drawing.Point(49, 49);
            this.lv_Voorraad.Name = "lv_Voorraad";
            this.lv_Voorraad.Size = new System.Drawing.Size(679, 324);
            this.lv_Voorraad.TabIndex = 1;
            this.lv_Voorraad.UseCompatibleStateImageBehavior = false;
            this.lv_Voorraad.View = System.Windows.Forms.View.Details;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Voorraad";
            // 
            // pnl_Werknemers
            // 
            this.pnl_Werknemers.Controls.Add(this.lv_Werknemers);
            this.pnl_Werknemers.Controls.Add(this.label3);
            this.pnl_Werknemers.Location = new System.Drawing.Point(12, 12);
            this.pnl_Werknemers.Name = "pnl_Werknemers";
            this.pnl_Werknemers.Size = new System.Drawing.Size(776, 426);
            this.pnl_Werknemers.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = "werknemers";
            // 
            // lv_Werknemers
            // 
            this.lv_Werknemers.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.lv_Werknemers.HideSelection = false;
            this.lv_Werknemers.Location = new System.Drawing.Point(49, 49);
            this.lv_Werknemers.Name = "lv_Werknemers";
            this.lv_Werknemers.Size = new System.Drawing.Size(679, 324);
            this.lv_Werknemers.TabIndex = 1;
            this.lv_Werknemers.UseCompatibleStateImageBehavior = false;
            this.lv_Werknemers.View = System.Windows.Forms.View.Details;
            // 
            // Eigenaar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pnl_Hoofdmenu);
            this.Controls.Add(this.pnl_Werknemers);
            this.Controls.Add(this.pnl_Voorraad);
            this.Name = "Eigenaar";
            this.Text = "Eigenaar";
            this.Load += new System.EventHandler(this.Eigenaar_Load);
            this.pnl_Hoofdmenu.ResumeLayout(false);
            this.pnl_Hoofdmenu.PerformLayout();
            this.pnl_Voorraad.ResumeLayout(false);
            this.pnl_Voorraad.PerformLayout();
            this.pnl_Werknemers.ResumeLayout(false);
            this.pnl_Werknemers.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl_Hoofdmenu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_Eigenaar_Werknemers;
        private System.Windows.Forms.Button btn_Eigenaar_Voorraad;
        private System.Windows.Forms.Panel pnl_Voorraad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel pnl_Werknemers;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ListView lv_Voorraad;
        private System.Windows.Forms.ListView lv_Werknemers;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
    }
}